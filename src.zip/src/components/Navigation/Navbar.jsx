import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css'; // Make sure to create this file

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/', icon: '🏠' },
    { name: 'Recipes', path: '/recipes', icon: '📖' },
    { name: 'Top Recipes', path: '/top-recipes', icon: '⭐' },
    { name: 'Shopping List', path: '/shopping-list', icon: '🛒' },
  ];

  const authLinks = [
    { name: 'Login', path: '/login' },
    { name: 'Register', path: '/register' },
  ];

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <div className="navbar-content">
          <Link to="/" className="navbar-logo">
            <div className="logo-container">
              <span className="logo-text dark-green">Meal</span>
              <span className="logo-text medium-green">Nest</span>
              <span className="logo-icon">🌿</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="desktop-nav">
            <div className="nav-links">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`nav-link ${location.pathname === link.path ? 'active' : ''}`}
                >
                  <div className="nav-link-content">
                    <span className="nav-icon">{link.icon}</span>
                    <span className="nav-text">{link.name}</span>
                  </div>
                  
                  {location.pathname === link.path && (
                    <span className="nav-underline"></span>
                  )}
                </Link>
              ))}
            </div>
            
            {/* Auth buttons */}
            <div className="auth-buttons">
              {authLinks.map((link, index) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`auth-button ${index === 0 ? 'login' : 'register'}`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="mobile-menu-button">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="menu-toggle"
            >
              <svg className="menu-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="mobile-nav">
          <div className="mobile-nav-container">
            <div className="mobile-nav-links">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`mobile-nav-link ${location.pathname === link.path ? 'active' : ''}`}
                  onClick={() => setIsOpen(false)}
                >
                  <span className="mobile-nav-icon">{link.icon}</span>
                  {link.name}
                  {location.pathname === link.path && (
                    <div className="mobile-active-indicator"></div>
                  )}
                </Link>
              ))}
              <div className="mobile-auth-buttons">
                {authLinks.map((link, index) => (
                  <Link
                    key={link.name}
                    to={link.path}
                    className={`mobile-auth-button ${index === 0 ? 'login' : 'register'}`}
                    onClick={() => setIsOpen(false)}
                  >
                    {link.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;