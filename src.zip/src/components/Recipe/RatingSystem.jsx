import React from 'react';
import './RatingSystem.css';

const RatingSystem = ({ rating, small = false }) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return (
    <div className={`rating-system ${small ? 'small' : ''}`}>
      {[...Array(fullStars)].map((_, i) => (
        <span key={`full-${i}`} className="star full-star">★</span>
      ))}
      
      {hasHalfStar && (
        <span className="star half-star">★</span>
      )}
      
      {[...Array(emptyStars)].map((_, i) => (
        <span key={`empty-${i}`} className="star empty-star">★</span>
      ))}
    </div>
  );
};

export default RatingSystem;