import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import RatingSystem from './RatingSystem';

const RecipeCard = ({ recipe }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-white rounded-lg shadow-sm overflow-hidden h-full flex flex-col"
    >
      <Link to={`/recipes/${recipe.id}`} className="block flex-grow">
        <div className="relative h-40 overflow-hidden">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
          />
          <div className="absolute top-2 right-2">
            <span className="inline-block px-2 py-1 text-xs bg-white bg-opacity-90 rounded-md text-gray-800 font-medium">
              {recipe.cookingTime} mins
            </span>
          </div>
        </div>
        
        <div className="p-3 flex-grow">
          <h3 className="font-medium text-gray-800 mb-1 line-clamp-1">{recipe.title}</h3>
          
          <div className="flex items-center mb-2">
            <RatingSystem rating={recipe.rating} small={true} />
            <span className="text-xs text-gray-500 ml-1">({recipe.reviews})</span>
          </div>
          
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-gray-500">By {recipe.author}</span>
            <span className="text-xs px-2 py-0.5 bg-green-50 text-green-700 rounded-full">
              {recipe.category}
            </span>
          </div>
          
          <p className="text-xs text-gray-600 line-clamp-2">{recipe.description}</p>
        </div>
      </Link>
      
      <div className="px-3 pb-3 pt-1 border-t border-gray-100">
        <button className="w-full text-xs font-medium text-green-700 hover:text-green-800 py-1 flex items-center justify-center">
          <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"></path>
          </svg>
          Save Recipe
        </button>
      </div>
    </motion.div>
  );
};

export default RecipeCard;