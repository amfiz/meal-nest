import React from 'react';
import { Document, Page, Text, View, StyleSheet } from '@react-pdf/renderer';

// Create styles
const styles = StyleSheet.create({
  page: {
    padding: 30,
    backgroundColor: '#FFFFFF',
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    marginBottom: 30,
  },
  section: {
    margin: 10,
    padding: 10,
  },
  sectionTitle: {
    fontSize: 16,
    marginBottom: 10,
    borderBottom: '1 solid #666',
    paddingBottom: 5,
  },
  categoryTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 15,
    marginBottom: 5,
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 3,
    paddingLeft: 10,
  },
  recipeItem: {
    marginBottom: 5,
    paddingLeft: 10,
  },
  text: {
    fontSize: 12,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 30,
    right: 30,
    textAlign: 'center',
    fontSize: 10,
    color: '#666',
  },
});

// Create Document Component
const ShoppingListPDF = ({ recipes, categorized }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <Text style={styles.title}>Shopping List</Text>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recipes</Text>
        {recipes.map((recipe, index) => (
          <Text key={index} style={styles.recipeItem}>• {recipe.name}</Text>
        ))}
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Ingredients</Text>
        {Object.keys(categorized).map((category, catIndex) => (
          <View key={catIndex}>
            <Text style={styles.categoryTitle}>{category}</Text>
            {categorized[category].map((item, itemIndex) => (
              <View key={itemIndex} style={styles.item}>
                <Text style={styles.text}>• {item.name}</Text>
                <Text style={styles.text}>{item.amount}</Text>
              </View>
            ))}
          </View>
        ))}
      </View>
      
      <Text style={styles.footer}>
        Generated on {new Date().toLocaleDateString()} • MealNest
      </Text>
    </Page>
  </Document>
);

export default ShoppingListPDF;