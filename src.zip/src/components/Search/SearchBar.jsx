import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const SearchBar = ({ onSearch, onFilterChange }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    diet: '',
    time: '',
    difficulty: '',
    ingredients: '',
  });

  const dietOptions = ['Any', 'Vegan', 'Vegetarian', 'Keto', 'Paleo', 'Gluten-Free'];
  const timeOptions = ['Any', '<15 mins', '<30 mins', '<60 mins', '>60 mins'];
  const difficultyOptions = ['Any', 'Easy', 'Medium', 'Hard'];

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch(searchQuery, filters);
  };

  const handleFilterChange = (filterType, value) => {
    const newFilters = { ...filters, [filterType]: value };
    setFilters(newFilters);
    onFilterChange(newFilters);
  };

  return (
    <div className="mb-8">
      <form onSubmit={handleSearch} className="relative">
        <input
          type="text"
          placeholder="Search recipes by name or ingredients..."
          className="w-full p-4 pl-12 pr-24 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary-light focus:border-transparent shadow-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button
          type="submit"
          className="absolute right-2 top-2 bg-primary-medium text-white px-4 py-2 rounded-md hover:bg-primary-dark transition-colors"
        >
          Search
        </button>
        <svg
          className="absolute left-4 top-4 h-5 w-5 text-gray-400"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
          />
        </svg>
        <button
          type="button"
          onClick={() => setShowFilters(!showFilters)}
          className="absolute right-28 top-2 flex items-center text-primary-medium hover:text-primary-dark"
        >
          <svg
            className="h-5 w-5 mr-1"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"
            />
          </svg>
          Filters
        </button>
      </form>

      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-4 p-4 bg-gray-50 rounded-lg overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Diet</label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md"
                  value={filters.diet}
                  onChange={(e) => handleFilterChange('diet', e.target.value)}
                >
                  {dietOptions.map((option) => (
                    <option key={option} value={option === 'Any' ? '' : option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md"
                  value={filters.time}
                  onChange={(e) => handleFilterChange('time', e.target.value)}
                >
                  {timeOptions.map((option) => (
                    <option key={option} value={option === 'Any' ? '' : option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Difficulty</label>
                <select
                  className="w-full p-2 border border-gray-300 rounded-md"
                  value={filters.difficulty}
                  onChange={(e) => handleFilterChange('difficulty', e.target.value)}
                >
                  {difficultyOptions.map((option) => (
                    <option key={option} value={option === 'Any' ? '' : option}>
                      {option}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ingredients</label>
                <input
                  type="text"
                  placeholder="Enter ingredients..."
                  className="w-full p-2 border border-gray-300 rounded-md"
                  value={filters.ingredients}
                  onChange={(e) => handleFilterChange('ingredients', e.target.value)}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchBar;