import React from 'react';
import './Home.css'; 

const Home = () => {
  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          <h1 className="hero-title">Welcome to <span className="logo-text">MealNest</span> 🌿</h1>
          <p className="hero-subtitle">Discover delicious recipes, save your favorites, and create shopping lists with ease.</p>
          <div className="hero-buttons">
            <a href="/recipes" className="primary-button">Browse Recipes</a>
            <a href="/register" className="secondary-button">Join Now</a>
          </div>
        </div>
      
        <div className="hero-image">
  <img
    src="3d.jpg"
    alt="Meal Image"
    className="hero-img"
  />
</div>

      </section>

      {/* Features Section */}
      <section className="features-section">
        <h2 className="section-title">Why Choose MealNest?</h2>
        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">📖</div>
            <h3 className="feature-title">Curated Recipes</h3>
            <p className="feature-text">Hand-picked recipes from professional chefs and home cooks alike.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">⭐</div>
            <h3 className="feature-title">Top Rated</h3>
            <p className="feature-text">See what recipes our community loves the most.</p>
          </div>
          <div className="feature-card">
            <div className="feature-icon">🛒</div>
            <h3 className="feature-title">Smart Shopping</h3>
            <p className="feature-text">Generate shopping lists from your saved recipes automatically.</p>
          </div>
        </div>
      </section>

      {/* Popular Recipes Section */}
      <section className="recipes-section">
        <h2 className="section-title">Popular This Week</h2>
        <div className="recipes-grid">
          
          <div className="recipe-card">
          <div className="recipe-image">
  <img src="Mediterranean Salad.jpg" alt="Recipe Image" />
</div>
            <div className="recipe-info">
              <h3 className="recipe-title">Mediterranean Salad</h3>
              <p className="recipe-meta">⭐ 4.8 (120 reviews)</p>
            </div>
          </div>
          <div className="recipe-card">
          <div className="recipe-image">
  <img src="Vegetable Stir Fry.jpg" alt="Recipe Image" />
</div>
            <div className="recipe-info">
              <h3 className="recipe-title">Vegetable Stir Fry</h3>
              <p className="recipe-meta">⭐ 4.6 (95 reviews)</p>
            </div>
          </div>
          <div className="recipe-card">
          <div className="recipe-image">
  <img src="Chocolate Avocado Mousse.jpg" alt="Recipe Image" />
</div>
            <div className="recipe-info">
              <h3 className="recipe-title">Chocolate Avocado Mousse</h3>
              <p className="recipe-meta">⭐ 4.9 (150 reviews)</p>
            </div>
          </div>
        </div>
        <a href="/recipes" className="view-all-button">View All Recipes →</a>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <h2 className="cta-title">Ready to start cooking?</h2>
        <p className="cta-text">Join thousands of home cooks who discover new recipes every day.</p>
        <div className="cta-buttons">
          <a href="/register" className="primary-button">Sign Up Free</a>
          <a href="/recipes" className="secondary-button">Browse Recipes</a>
        </div>
      </section>
    </div>
  );
};

export default Home;