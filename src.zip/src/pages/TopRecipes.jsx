

import React, { useState, useEffect } from 'react';
import RecipeCard from '../components/Recipe/RecipeCard';
import './TopRecipes.css';

const allSampleRecipes = {
  week: [
    {
      id: 1,
      title: 'Avocado Toast',
      image: 'D:\meal-nest\src\pages\avocado-toast-with-egg.jpg',
      author: 'Chef John',
      description: 'Simple yet delicious avocado toast with chili flakes and lemon juice.',
      rating: 4.6,
      reviews: 87,
      cookingTime: 10,
      category: 'Breakfast',
      tags: ['quick', 'healthy', 'vegan'],
      likes: 108,
      saves: 55,
    },
    {
      id: 2,
      title: 'Vegetable Stir Fry',
      image: '/stir-fry.jpg',
      author: 'Chef Tom',
      description: 'Quick and easy stir fry with a savory sauce, ready in 15 minutes.',
      rating: 4.4,
      reviews: 75,
      cookingTime: 15,
      category: 'Asian',
      tags: ['quick', 'vegetarian', 'healthy'],
      likes: 98,
      saves: 44,
    },
    {
      id: 7,
      title: 'Breakfast Smoothie Bowl',
      image: '/smoothie-bowl.jpg',
      author: 'Chef Emma',
      description: 'Nutrient-packed smoothie bowl topped with fresh fruits and granola.',
      rating: 4.7,
      reviews: 92,
      cookingTime: 12,
      category: 'Breakfast',
      tags: ['quick', 'healthy', 'vegan'],
      likes: 135,
      saves: 87,
    },
    {
      id: 8,
      title: 'One-Pot Pasta',
      image: '/one-pot-pasta.jpg',
      author: 'Chef David',
      description: 'Easy one-pot pasta with tomatoes, basil, and garlic. Minimal cleanup required!',
      rating: 4.5,
      reviews: 68,
      cookingTime: 20,
      category: 'Italian',
      tags: ['quick', 'easy', 'weeknight'],
      likes: 115,
      saves: 62,
    },
  ],
  month: [
    {
      id: 3,
      title: 'Chicken Tikka Masala',
      image: '/chicken-tikka.jpg',
      author: 'Chef Ali',
      description: 'Classic Indian dish with marinated chicken in rich tomato sauce.',
      rating: 4.9,
      reviews: 156,
      cookingTime: 45,
      category: 'Indian',
      tags: ['chicken', 'spicy', 'main course'],
      likes: 212,
      saves: 97,
    },
    {
      id: 4,
      title: 'Keto Cauliflower Rice',
      image: '/cauliflower-rice.jpg',
      author: 'Chef Sarah',
      description: 'Low-carb rice with garlic and herbs for keto diets.',
      rating: 4.5,
      reviews: 92,
      cookingTime: 25,
      category: 'Keto',
      tags: ['keto', 'low-carb', 'healthy'],
      likes: 176,
      saves: 83,
    },
    {
      id: 9,
      title: 'Mediterranean Quinoa Bowl',
      image: '/quinoa-bowl.jpg',
      author: 'Chef Sophia',
      description: 'Protein-rich quinoa with roasted vegetables, feta cheese, and olive oil dressing.',
      rating: 4.8,
      reviews: 124,
      cookingTime: 30,
      category: 'Mediterranean',
      tags: ['healthy', 'vegetarian', 'meal prep'],
      likes: 195,
      saves: 110,
    },
    {
      id: 10,
      title: 'Spicy Fish Tacos',
      image: '/fish-tacos.jpg',
      author: 'Chef Miguel',
      description: 'Fresh fish tacos with homemade slaw and spicy mayo.',
      rating: 4.7,
      reviews: 138,
      cookingTime: 35,
      category: 'Mexican',
      tags: ['seafood', 'spicy', 'dinner'],
      likes: 187,
      saves: 92,
    },
  ],
  all: [
    {
      id: 5,
      title: 'Creamy Garlic Pasta',
      image: '/pasta.jpg',
      author: 'Chef Maria',
      description: 'Delicious creamy pasta with garlic and parmesan in 20 minutes.',
      rating: 4.8,
      reviews: 215,
      cookingTime: 20,
      category: 'Italian',
      tags: ['pasta', 'quick', 'vegetarian'],
      likes: 342,
      saves: 128,
    },
    {
      id: 6,
      title: 'Chocolate Avocado Mousse',
      image: '/chocolate-mousse.jpg',
      author: 'Chef Lisa',
      description: 'Healthy dessert made with avocado and dark chocolate.',
      rating: 4.7,
      reviews: 198,
      cookingTime: 15,
      category: 'Dessert',
      tags: ['dessert', 'healthy', 'vegan'],
      likes: 324,
      saves: 156,
    },
    {
      id: 11,
      title: 'Slow Cooker Beef Stew',
      image: '/beef-stew.jpg',
      author: 'Chef Robert',
      description: 'Hearty beef stew with vegetables, perfect for cold days.',
      rating: 4.9,
      reviews: 287,
      cookingTime: 240,
      category: 'Comfort Food',
      tags: ['slow cooker', 'beef', 'winter'],
      likes: 421,
      saves: 195,
    },
    {
      id: 12,
      title: 'Classic Sourdough Bread',
      image: '/sourdough.jpg',
      author: 'Chef Julia',
      description: 'Traditional sourdough bread with perfect crust and tangy flavor.',
      rating: 4.8,
      reviews: 264,
      cookingTime: 180,
      category: 'Baking',
      tags: ['bread', 'baking', 'artisan'],
      likes: 389,
      saves: 201,
    },
    {
      id: 13,
      title: 'Vietnamese Pho',
      image: '/pho.jpg',
      author: 'Chef Nguyen',
      description: 'Aromatic beef noodle soup with fresh herbs and spices.',
      rating: 4.9,
      reviews: 312,
      cookingTime: 120,
      category: 'Asian',
      tags: ['soup', 'comfort food', 'dinner'],
      likes: 402,
      saves: 187,
    },
    {
      id: 14,
      title: 'Berry Chia Pudding',
      image: '/chia-pudding.jpg',
      author: 'Chef Anna',
      description: 'Overnight chia seed pudding with mixed berries and honey.',
      rating: 4.6,
      reviews: 178,
      cookingTime: 480,
      category: 'Breakfast',
      tags: ['make ahead', 'healthy', 'vegan'],
      likes: 286,
      saves: 167,
    },
  ],
};

const RecipeDetailView = ({ recipe, onBack }) => {
  return (
    <div className="recipe-detail-view">
      <button onClick={onBack} className="back-button">
        ← Back to top recipes
      </button>
      
      <div className="recipe-detail-header">
        <div className="recipe-detail-image">
          <img src={recipe.image} alt={recipe.title} />
        </div>
        <div className="recipe-detail-meta">
          <h1>{recipe.title}</h1>
          <p className="recipe-description">{recipe.description}</p>
          
          <div className="recipe-ratings">
            <div className="stars">
              {'★'.repeat(Math.floor(recipe.rating))}
              {'☆'.repeat(5 - Math.floor(recipe.rating))}
            </div>
            <span>({recipe.reviews} reviews)</span>
          </div>
          
          <div className="recipe-meta-grid">
            <div className="meta-item">
              <span className="meta-label">Prep</span>
              <span className="meta-value">5 mins</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Cook</span>
              <span className="meta-value">{recipe.cookingTime} mins</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Difficulty</span>
              <span className="meta-value">Easy</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Servings</span>
              <span className="meta-value">2-4</span>
            </div>
          </div>
          
          <div className="recipe-tags">
            {recipe.tags.map(tag => (
              <span key={tag} className="tag">{tag}</span>
            ))}
          </div>
        </div>
      </div>
      
      <div className="recipe-detail-content">
        <div className="recipe-ingredients">
          <h2>Ingredients</h2>
          <ul>
            <li>8 oz pasta</li>
            <li>2 tbsp butter</li>
            <li>4 cloves garlic, minced</li>
            <li>1 cup heavy cream</li>
            <li>1/2 cup grated parmesan</li>
            <li>Salt and pepper to taste</li>
            <li>Fresh parsley for garnish</li>
          </ul>
        </div>
        
        <div className="recipe-instructions">
          <h2>Instructions</h2>
          <ol>
            <li>Cook pasta according to package instructions in salted water until al dente. Reserve 1/2 cup of pasta water before draining.</li>
            <li>While pasta cooks, melt butter in a large skillet over medium heat. Add minced garlic and sauté for 1-2 minutes until fragrant but not browned.</li>
            <li>Pour in heavy cream and bring to a simmer. Let cook for 2-3 minutes until slightly thickened.</li>
            <li>Reduce heat to low and stir in grated parmesan cheese until melted and smooth. If sauce is too thick, add reserved pasta water a tablespoon at a time.</li>
            <li>Add drained pasta to the skillet and toss to coat in the sauce. Season with salt and pepper to taste.</li>
            <li>Garnish with chopped parsley and serve immediately with extra parmesan if desired.</li>
          </ol>
        </div>
      </div>
      
      <div className="recipe-nutrition">
        <h2>Nutrition Information (per serving)</h2>
        <div className="nutrition-grid">
          <div className="nutrition-item">
            <span className="nutrition-value">650</span>
            <span className="nutrition-label">Calories</span>
          </div>
          <div className="nutrition-item">
            <span className="nutrition-value">45g</span>
            <span className="nutrition-label">Carbs</span>
          </div>
          <div className="nutrition-item">
            <span className="nutrition-value">15g</span>
            <span className="nutrition-label">Protein</span>
          </div>
          <div className="nutrition-item">
            <span className="nutrition-value">45g</span>
            <span className="nutrition-label">Fat</span>
          </div>
        </div>
      </div>
      
      <div className="recipe-author">
        <h3>By {recipe.author}</h3>
      </div>
      
      <div className="recipe-comments">
        <h2>Comments (2)</h2>
        {/* Comments would go here */}
      </div>
      
      <div className="similar-recipes">
        <h2>Similar Recipes</h2>
        <div className="similar-recipes-grid">
          {/* Similar recipes would go here */}
        </div>
      </div>
    </div>
  );
};

const TopRecipes = () => {
  const [topRecipes, setTopRecipes] = useState([]);
  const [timeRange, setTimeRange] = useState('week');
  const [isLoading, setIsLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedRecipe, setSelectedRecipe] = useState(null);
  
  const categoryOptions = ['all', 'Breakfast', 'Italian', 'Asian', 'Dessert', 'Indian', 'Keto', 'Mediterranean', 'Mexican', 'Comfort Food', 'Baking'];

  useEffect(() => {
    const fetchRecipesByTime = async () => {
      setIsLoading(true);
      await new Promise(resolve => setTimeout(resolve, 500)); // simulate delay

      const recipes = allSampleRecipes[timeRange] || [];
      const sorted = [...recipes].sort((a, b) => (b.likes + b.saves) - (a.likes + a.saves));
      setTopRecipes(sorted);
      setIsLoading(false);
    };

    fetchRecipesByTime();
  }, [timeRange]);

  const filteredRecipes = categoryFilter === 'all' 
    ? topRecipes 
    : topRecipes.filter(recipe => recipe.category === categoryFilter);

  const handleRecipeClick = (recipe) => {
    setSelectedRecipe(recipe);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToList = () => {
    setSelectedRecipe(null);
  };

  return (
    <div className="top-recipes-container">
      {selectedRecipe ? (
        <RecipeDetailView recipe={selectedRecipe} onBack={handleBackToList} />
      ) : (
        <>
          <div className="top-recipes-header">
            <h1 className="top-recipes-title">Top Recipes</h1>
            <div className="filters-container">
              <div className="time-filters">
                {['week', 'month', 'all'].map(range => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`filter-button ${timeRange === range ? 'active' : ''}`}
                  >
                    {range === 'week' ? 'This Week' : range === 'month' ? 'This Month' : 'All Time'}
                  </button>
                ))}
              </div>
              <div className="category-filter">
                <select 
                  value={categoryFilter} 
                  onChange={(e) => setCategoryFilter(e.target.value)}
                  className="category-select"
                >
                  {categoryOptions.map(category => (
                    <option key={category} value={category}>
                      {category === 'all' ? 'All Categories' : category}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="loading-container">
              <div className="loading-spinner"></div>
            </div>
          ) : filteredRecipes.length > 0 ? (
            <div className="recipes-grid">
              {filteredRecipes.map((recipe, index) => (
                <div 
                  key={recipe.id} 
                  className="recipe-item fade-in" 
                  style={{animationDelay: `${index * 100}ms`}}
                  onClick={() => handleRecipeClick(recipe)}
                >
                  <div className="recipe-card-container">
                    {index < 3 && (
                      <div className={`position-badge position-${index + 1}`}>
                        #{index + 1}
                      </div>
                    )}
                    <RecipeCard recipe={recipe} />
                  </div>
                  <div className="recipe-stats">
                    <span className="recipe-likes">
                      ❤️ {recipe.likes} likes
                    </span>
                    <span className="recipe-saves">
                      🔖 {recipe.saves} saves
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="no-recipes">No top recipes found for this category.</div>
          )}

          {!isLoading && filteredRecipes.length > 0 && (
            <div className="community-stats fade-in">
              <h2 className="stats-title">Community Engagement</h2>
              <div className="stats-grid">
                <div className="stat-card">
                  <div className="stat-value">
                    {filteredRecipes.reduce((sum, r) => sum + r.likes, 0)}
                  </div>
                  <div className="stat-label">Total Likes</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">
                    {filteredRecipes.reduce((sum, r) => sum + r.saves, 0)}
                  </div>
                  <div className="stat-label">Total Saves</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">
                    {filteredRecipes.reduce((sum, r) => sum + r.reviews, 0)}
                  </div>
                  <div className="stat-label">Total Reviews</div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default TopRecipes;
