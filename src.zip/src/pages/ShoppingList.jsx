import React, { useState, useEffect } from 'react';
import { PDFDownloadLink } from '@react-pdf/renderer';
import ShoppingListPDF from '../components/ShoppingList/ShoppingListPDF';
import './ShoppingList.css';

const ShoppingList = () => {
  // Sample recipe data
  const recipeData = [
    { 
      id: 1, 
      name: 'Pasta Carbonara', 
      ingredients: [
        { name: 'Pasta', amount: '400g', category: 'Grains' },
        { name: 'Eggs', amount: '4 large', category: 'Dairy' },
        { name: 'Bacon', amount: '200g', category: 'Meat' },
        { name: 'Parmesan', amount: '100g, grated', category: 'Dairy' }
      ] 
    },
    { 
      id: 2, 
      name: 'Chicken Curry', 
      ingredients: [
        { name: 'Chicken Breast', amount: '500g', category: 'Meat' },
        { name: 'Curry Paste', amount: '3 tbsp', category: 'Condiments' },
        { name: 'Coconut Milk', amount: '400ml', category: 'Dairy' },
        { name: 'Rice', amount: '300g', category: 'Grains' }
      ] 
    },
    { 
      id: 3, 
      name: 'Caesar Salad', 
      ingredients: [
        { name: 'Romaine Lettuce', amount: '1 head', category: 'Vegetables' },
        { name: 'Croutons', amount: '100g', category: 'Bakery' },
        { name: 'Parmesan', amount: '50g, shaved', category: 'Dairy' },
        { name: 'Caesar Dressing', amount: '120ml', category: 'Condiments' }
      ] 
    },
    { 
      id: 4, 
      name: 'Beef Stir Fry', 
      ingredients: [
        { name: 'Beef Strips', amount: '400g', category: 'Meat' },
        { name: 'Bell Peppers', amount: '2', category: 'Vegetables' },
        { name: 'Soy Sauce', amount: '4 tbsp', category: 'Condiments' },
        { name: 'Rice', amount: '300g', category: 'Grains' }
      ] 
    }
  ];

  const [selectedRecipes, setSelectedRecipes] = useState([]);
  const [availableRecipes, setAvailableRecipes] = useState(recipeData);
  const [shoppingList, setShoppingList] = useState([]);
  const [categorizedList, setCategorizedList] = useState({});

  // Update shopping list whenever selected recipes change
  useEffect(() => {
    const newShoppingList = [];
    const categorized = {};
    
    selectedRecipes.forEach(recipe => {
      recipe.ingredients.forEach(ingredient => {
        // Check if ingredient already exists in list
        const existingIndex = newShoppingList.findIndex(item => item.name === ingredient.name);
        
        if (existingIndex === -1) {
          // Add to shopping list
          newShoppingList.push({...ingredient});
          
          // Add to categorized list
          if (!categorized[ingredient.category]) {
            categorized[ingredient.category] = [];
          }
          categorized[ingredient.category].push({...ingredient});
        }
      });
    });
    
    setShoppingList(newShoppingList);
    setCategorizedList(categorized);
  }, [selectedRecipes]);

  // Toggle recipe selection
  const toggleRecipeSelection = (recipe) => {
    if (selectedRecipes.find(r => r.id === recipe.id)) {
      setSelectedRecipes(selectedRecipes.filter(r => r.id !== recipe.id));
    } else {
      setSelectedRecipes([...selectedRecipes, recipe]);
    }
  };

  return (
    <div className="shopping-list-container">
      <h1 className="shopping-list-title">Shopping List Generator</h1>
      
      {/* Available Recipes Section - SIMPLIFIED */}
      <div className="section-container">
        <h2 className="section-title">Available Recipes</h2>
        
        {/* Recipe Table - Simple and visible approach */}
        <table className="recipe-table">
          <thead>
            <tr>
              <th>Recipe</th>
              <th>Ingredients</th>
              <th>Select</th>
            </tr>
          </thead>
          <tbody>
            {availableRecipes.map(recipe => (
              <tr key={recipe.id} className={selectedRecipes.find(r => r.id === recipe.id) ? 'selected-row' : ''}>
                <td className="recipe-name">{recipe.name}</td>
                <td className="recipe-ingredients">
                  {recipe.ingredients.map(ing => ing.name).join(', ')}
                </td>
                <td className="recipe-select">
                  <input 
                    type="checkbox" 
                    checked={!!selectedRecipes.find(r => r.id === recipe.id)}
                    onChange={() => toggleRecipeSelection(recipe)}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Selected Recipes Section */}
      <div className="section-container">
        <h2 className="section-title">Selected Recipes</h2>
        {selectedRecipes.length > 0 ? (
          <div className="selected-recipes">
            {selectedRecipes.map(recipe => (
              <div key={recipe.id} className="selected-recipe-pill">
                <span>{recipe.name}</span>
                <button 
                  className="remove-button" 
                  onClick={() => toggleRecipeSelection(recipe)}
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="empty-message">No recipes selected yet</p>
        )}
      </div>
      
      {/* Shopping List Section */}
      <div className="section-container">
        <h2 className="section-title">Shopping List</h2>
        {shoppingList.length > 0 ? (
          <>
            {/* Categorized Shopping List */}
            <div className="shopping-list">
              {Object.keys(categorizedList).map(category => (
                <div key={category} className="category-section">
                  <h3 className="category-title">{category}</h3>
                  <ul className="category-items">
                    {categorizedList[category].map((item, index) => (
                      <li key={index} className="ingredient-item">
                        <span className="ingredient-name">{item.name}</span>
                        <span className="ingredient-amount">{item.amount}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            
            {/* Download Button */}
            <div className="download-section">
              {selectedRecipes.length > 0 && (
                <PDFDownloadLink
                  document={<ShoppingListPDF recipes={selectedRecipes} categorized={categorizedList} />}
                  fileName="shopping-list.pdf"
                  className="download-button"
                >
                  {({ loading }) => loading ? 'Preparing PDF...' : 'Download Shopping List'}
                </PDFDownloadLink>
              )}
            </div>
          </>
        ) : (
          <p className="empty-message">Your shopping list will appear here</p>
        )}
      </div>
    </div>
  );
};

export default ShoppingList;