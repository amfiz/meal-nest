import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import CommentSection from '../components/Recipe/CommentSection';
import RatingSystem from '../components/Recipe/RatingSystem';
import './RecipeDetail.css';

const RecipeDetail = () => {
  const { id } = useParams();
  const [recipe, setRecipe] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('instructions');
  const [servings, setServings] = useState(2);
  const [isSaved, setIsSaved] = useState(false);

  // Combined recipe data
  const allSampleRecipes = {
    week: [
      {
        id: 1,
        title: 'Avocado Toast',
        image: "avocado-toast-with-egg.jpg",
        author: 'Chef John',
        authorId: 5,
        description: 'Simple yet delicious avocado toast with chili flakes and lemon juice.',
        rating: 4.6,
        reviews: 87,
        prepTime: 5,
        cookingTime: 10,
        category: 'Breakfast',
        tags: ['quick', 'healthy', 'vegan'],
        likes: 108,
        saves: 55,
        difficulty: 'Easy',
        ingredients: [
          { name: 'Whole grain bread', amount: '2 slices', note: 'toasted' },
          { name: 'Ripe avocados', amount: '1 large', note: 'mashed' },
          { name: 'Lemon juice', amount: '1 tsp' },
          { name: 'Red pepper flakes', amount: '1/4 tsp' },
          { name: 'Sea salt', amount: 'to taste' },
          { name: 'Black pepper', amount: 'to taste' },
          { name: 'Olive oil', amount: '1 tsp', note: 'for drizzling' },
        ],
        instructions: [
          'Toast the bread slices until golden and crisp.',
          'In a small bowl, mash the avocado with a fork.',
          'Mix in the lemon juice, salt, and pepper to taste.',
          'Spread the avocado mixture onto the toast.',
          'Sprinkle with red pepper flakes and drizzle with olive oil.',
          'Serve immediately.',
        ],
        nutrition: {
          calories: 320,
          carbs: '32g',
          protein: '8g',
          fat: '21g',
        },
        comments: [
          {
            id: 1,
            userId: 2,
            username: 'HealthyEater',
            avatar: '/avatar1.jpg',
            text: 'Perfect breakfast option! I added a poached egg on top for extra protein.',
            rating: 5,
            date: '2023-05-15',
          },
          {
            id: 2,
            userId: 3,
            username: 'VeganChef',
            avatar: '/avatar2.jpg',
            text: 'So simple yet so delicious. I added some microgreens on top for extra nutrients.',
            rating: 4,
            date: '2023-05-10',
          },
        ],
      },
      {
        id: 2,
        title: 'Vegetable Stir Fry',
        image: '/stir-fry.jpg',
        author: 'Chef Tom',
        authorId: 8,
        description: 'Quick and easy stir fry with a savory sauce, ready in 15 minutes.',
        rating: 4.4,
        reviews: 75,
        prepTime: 10,
        cookingTime: 15,
        category: 'Asian',
        tags: ['quick', 'vegetarian', 'healthy'],
        likes: 98,
        saves: 44,
        difficulty: 'Easy',
        ingredients: [
          { name: 'Mixed vegetables', amount: '4 cups', note: 'broccoli, bell peppers, carrots, snap peas' },
          { name: 'Garlic', amount: '3 cloves', note: 'minced' },
          { name: 'Ginger', amount: '1 tbsp', note: 'grated' },
          { name: 'Soy sauce', amount: '3 tbsp' },
          { name: 'Sesame oil', amount: '1 tbsp' },
          { name: 'Vegetable oil', amount: '2 tbsp' },
          { name: 'Cornstarch', amount: '1 tsp', note: 'mixed with 2 tbsp water' },
        ],
        instructions: [
          'Heat vegetable oil in a wok or large pan over high heat.',
          'Add garlic and ginger, stir for 30 seconds until fragrant.',
          'Add vegetables and stir fry for 5-7 minutes until tender-crisp.',
          'Mix soy sauce and sesame oil in a small bowl.',
          'Pour sauce over vegetables and toss to coat.',
          'Add cornstarch mixture and cook until sauce thickens, about 1 minute.',
          'Serve hot over rice or noodles if desired.',
        ],
        nutrition: {
          calories: 180,
          carbs: '15g',
          protein: '5g',
          fat: '12g',
        },
        comments: [
          {
            id: 1,
            userId: 4,
            username: 'StirFryFan',
            avatar: '/avatar3.jpg',
            text: 'Great recipe! I added some tofu for protein and it was delicious.',
            rating: 5,
            date: '2023-04-20',
          },
          {
            id: 2,
            userId: 5,
            username: 'QuickMealMom',
            avatar: '/avatar4.jpg',
            text: 'My kids loved this! Easy weeknight dinner that everyone enjoyed.',
            rating: 4,
            date: '2023-04-15',
          },
        ],
      },
      // Add similar detailed data for other recipes
    ],
    month: [
      {
        id: 3,
        title: 'Chicken Tikka Masala',
        image: '/chicken-tikka.jpg',
        author: 'Chef Ali',
        authorId: 10,
        description: 'Classic Indian dish with marinated chicken in rich tomato sauce.',
        rating: 4.9,
        reviews: 156,
        prepTime: 30,
        cookingTime: 45,
        category: 'Indian',
        tags: ['chicken', 'spicy', 'main course'],
        likes: 212,
        saves: 97,
        difficulty: 'Medium',
        ingredients: [
          { name: 'Chicken breast', amount: '2 lbs', note: 'cut into 1-inch cubes' },
          { name: 'Plain yogurt', amount: '1 cup' },
          { name: 'Lemon juice', amount: '2 tbsp' },
          { name: 'Garam masala', amount: '2 tbsp' },
          { name: 'Ground cumin', amount: '1 tsp' },
          { name: 'Ground coriander', amount: '1 tsp' },
          { name: 'Turmeric', amount: '1 tsp' },
          { name: 'Paprika', amount: '1 tsp' },
          { name: 'Tomato sauce', amount: '2 cups' },
          { name: 'Heavy cream', amount: '1 cup' },
          { name: 'Onion', amount: '1 large', note: 'finely chopped' },
          { name: 'Garlic', amount: '4 cloves', note: 'minced' },
          { name: 'Ginger', amount: '1 tbsp', note: 'grated' },
          { name: 'Butter', amount: '2 tbsp' },
          { name: 'Fresh cilantro', amount: '1/4 cup', note: 'chopped, for garnish' },
        ],
        instructions: [
          'In a large bowl, combine yogurt, lemon juice, and spices. Add chicken and marinate for at least 2 hours.',
          'Preheat oven to 400°F (200°C). Thread chicken onto skewers and bake for 15 minutes.',
          'Meanwhile, melt butter in a large pan over medium heat. Add onion and sauté until soft.',
          'Add garlic and ginger, cook for 1 minute until fragrant.',
          'Pour in tomato sauce and bring to a simmer. Cook for 10 minutes.',
          'Add cooked chicken and simmer for another 10 minutes.',
          'Stir in heavy cream and cook for 5 more minutes.',
          'Garnish with fresh cilantro and serve with rice or naan.',
        ],
        nutrition: {
          calories: 450,
          carbs: '12g',
          protein: '35g',
          fat: '28g',
        },
        comments: [
          {
            id: 1,
            userId: 6,
            username: 'SpiceEnthusiast',
            avatar: '/avatar5.jpg',
            text: 'Just like my favorite restaurant! The spice level was perfect.',
            rating: 5,
            date: '2023-03-25',
          },
          {
            id: 2,
            userId: 7,
            username: 'HomeChef101',
            avatar: '/avatar6.jpg',
            text: 'Delicious recipe! I added a bit more cream to make it milder for my kids.',
            rating: 5,
            date: '2023-03-20',
          },
        ],
      },
      // Add similar detailed data for other recipes
    ],
    all: [
      {
        id: 5,
        title: 'Creamy Garlic Pasta',
        image: '/pasta.jpg',
        author: 'Chef Maria',
        authorId: 1,
        description: 'A delicious creamy pasta with garlic and parmesan cheese that comes together in just 20 minutes. Perfect for a quick weeknight dinner that feels special enough for company!',
        rating: 4.8,
        reviews: 215,
        prepTime: 5,
        cookingTime: 20,
        category: 'Italian',
        tags: ['pasta', 'quick', 'vegetarian'],
        likes: 342,
        saves: 128,
        difficulty: 'Easy',
        ingredients: [
          { name: 'Pasta', amount: '8 oz', note: 'fettuccine or linguine' },
          { name: 'Butter', amount: '2 tbsp' },
          { name: 'Garlic', amount: '4 cloves', note: 'minced' },
          { name: 'Heavy cream', amount: '1 cup' },
          { name: 'Parmesan cheese', amount: '1/2 cup', note: 'grated' },
          { name: 'Salt and pepper', amount: 'to taste' },
          { name: 'Fresh parsley', amount: '2 tbsp', note: 'chopped (for garnish)' },
        ],
        instructions: [
          'Cook pasta according to package instructions in salted water until al dente. Reserve 1/2 cup of pasta water before draining.',
          'While pasta cooks, melt butter in a large skillet over medium heat. Add minced garlic and sauté for 1-2 minutes until fragrant but not browned.',
          'Pour in heavy cream and bring to a simmer. Let cook for 2-3 minutes until slightly thickened.',
          'Reduce heat to low and stir in grated parmesan cheese until melted and smooth. If sauce is too thick, add reserved pasta water a tablespoon at a time.',
          'Add drained pasta to the skillet and toss to coat in the sauce. Season with salt and pepper to taste.',
          'Garnish with chopped parsley and serve immediately with extra parmesan if desired.',
        ],
        nutrition: {
          calories: 650,
          carbs: '45g',
          protein: '15g',
          fat: '45g',
        },
        comments: [
          {
            id: 1,
            userId: 2,
            username: 'FoodLover22',
            avatar: '/avatar1.jpg',
            text: 'This pasta is amazing! Made it for date night and my partner loved it.',
            rating: 5,
            date: '2023-05-15',
          },
          {
            id: 2,
            userId: 3,
            username: 'HomeChef',
            avatar: '/avatar2.jpg',
            text: 'I added some mushrooms and spinach for extra veggies. Turned out great!',
            rating: 4,
            date: '2023-05-10',
          },
        ],
      },
      // Add similar detailed data for other recipes
    ],
  };

  // Combine all recipes into a single flat array
  const allRecipes = [
    ...allSampleRecipes.week,
    ...allSampleRecipes.month,
    ...allSampleRecipes.all.filter(recipe => 
      !allSampleRecipes.week.some(r => r.id === recipe.id) && 
      !allSampleRecipes.month.some(r => r.id === recipe.id)
    )
  ];

  // Simulate fetching a single recipe from an API
  useEffect(() => {
    const fetchRecipe = async () => {
      setIsLoading(true);
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 600));
        
        // Find recipe by ID
        const recipeId = parseInt(id);
        const foundRecipe = allRecipes.find(r => r.id === recipeId);
        setRecipe(foundRecipe);
      } catch (error) {
        console.error('Error fetching recipe:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecipe();
  }, [id]);

  const adjustServings = (direction) => {
    if (direction === 'increase' && servings < 10) {
      setServings(servings + 1);
    } else if (direction === 'decrease' && servings > 1) {
      setServings(servings - 1);
    }
  };

  const handleSaveRecipe = () => {
    setIsSaved(!isSaved);
    // In a real app, you would call an API to save/unsave the recipe for the user
  };

  // Find similar recipes based on category or tags
  const getSimilarRecipes = () => {
    if (!recipe) return [];
    
    return allRecipes
      .filter(r => 
        r.id !== recipe.id && 
        (r.category === recipe.category || 
         r.tags.some(tag => recipe.tags.includes(tag)))
      )
      .sort(() => 0.5 - Math.random()) // Shuffle
      .slice(0, 3); // Take 3 random similar recipes
  };

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="recipe-not-found">
        <h2>Recipe not found</h2>
        <Link to="/recipes" className="back-button">Browse Recipes</Link>
      </div>
    );
  }

  return (
    <div className="recipe-detail-view">
      <Link to="/top-recipes" className="back-button">
        ← Back to top recipes
      </Link>
      
      <div className="recipe-detail-header">
        <div className="recipe-detail-image">
          <img src={recipe.image} alt={recipe.title} />
          <button
            onClick={handleSaveRecipe}
            className={`save-button ${isSaved ? 'saved' : ''}`}
            aria-label={isSaved ? 'Unsave recipe' : 'Save recipe'}
          >
            {isSaved ? '★ Saved' : '☆ Save'}
          </button>
        </div>
        <div className="recipe-detail-meta">
          <h1>{recipe.title}</h1>
          <p className="recipe-description">{recipe.description}</p>
          
          <div className="recipe-ratings">
            <div className="stars">
              {'★'.repeat(Math.floor(recipe.rating))}
              {'☆'.repeat(5 - Math.floor(recipe.rating))}
            </div>
            <span>({recipe.reviews} reviews)</span>
          </div>
          
          <div className="recipe-meta-grid">
            <div className="meta-item">
              <span className="meta-label">Prep</span>
              <span className="meta-value">{recipe.prepTime} mins</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Cook</span>
              <span className="meta-value">{recipe.cookingTime} mins</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Difficulty</span>
              <span className="meta-value">{recipe.difficulty}</span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Servings</span>
              <span className="meta-value">
                {servings}
                <button
                  onClick={() => adjustServings('decrease')}
                  className="serving-button"
                  disabled={servings <= 1}
                >
                  -
                </button>
                <button
                  onClick={() => adjustServings('increase')}
                  className="serving-button"
                  disabled={servings >= 10}
                >
                  +
                </button>
              </span>
            </div>
          </div>
          
          <div className="recipe-tags">
            {recipe.tags.map(tag => (
              <span key={tag} className="tag">{tag}</span>
            ))}
          </div>
        </div>
      </div>
      
      <div className="recipe-tabs">
        <button 
          onClick={() => setActiveTab('instructions')}
          className={activeTab === 'instructions' ? 'active' : ''}
        >
          Instructions
        </button>
        <button 
          onClick={() => setActiveTab('ingredients')}
          className={activeTab === 'ingredients' ? 'active' : ''}
        >
          Ingredients
        </button>
        <button 
          onClick={() => setActiveTab('nutrition')}
          className={activeTab === 'nutrition' ? 'active' : ''}
        >
          Nutrition
        </button>
        <button 
          onClick={() => setActiveTab('comments')}
          className={activeTab === 'comments' ? 'active' : ''}
        >
          Comments ({recipe.comments.length})
        </button>
      </div>
      
      <div className="recipe-detail-content">
        {activeTab === 'instructions' && (
          <div className="recipe-instructions">
            <h2>Cooking Instructions</h2>
            <ol>
              {recipe.instructions.map((step, index) => (
                <li key={index}>{step}</li>
              ))}
            </ol>
          </div>
        )}
        
        {activeTab === 'ingredients' && (
          <div className="recipe-ingredients">
            <h2>Ingredients</h2>
            <ul>
              {recipe.ingredients.map((ingredient, index) => (
                <li key={index}>
                  <span className="ingredient-checkbox"></span>
                  <span className="ingredient-text">
                    <strong>{ingredient.amount} {ingredient.name}</strong>
                    {ingredient.note && <span className="ingredient-note"> ({ingredient.note})</span>}
                  </span>
                </li>
              ))}
            </ul>
            <button className="add-shopping-list-button">
              Add to Shopping List
            </button>
          </div>
        )}
        
        {activeTab === 'nutrition' && (
          <div className="recipe-nutrition">
            <h2>Nutrition Facts</h2>
            <div className="nutrition-grid">
              <div className="nutrition-item">
                <span className="nutrition-value">{recipe.nutrition.calories}</span>
                <span className="nutrition-label">Calories</span>
              </div>
              <div className="nutrition-item">
                <span className="nutrition-value">{recipe.nutrition.carbs}</span>
                <span className="nutrition-label">Carbs</span>
              </div>
              <div className="nutrition-item">
                <span className="nutrition-value">{recipe.nutrition.protein}</span>
                <span className="nutrition-label">Protein</span>
              </div>
              <div className="nutrition-item">
                <span className="nutrition-value">{recipe.nutrition.fat}</span>
                <span className="nutrition-label">Fat</span>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'comments' && (
          <div className="recipe-comments">
            <h2>Comments</h2>
            {recipe.comments.map(comment => (
              <div key={comment.id} className="comment">
                <div className="comment-header">
                  <img src={comment.avatar} alt={comment.username} className="comment-avatar" />
                  <div className="comment-meta">
                    <div className="comment-username">{comment.username}</div>
                    <div className="comment-date">{comment.date}</div>
                  </div>
                  <div className="comment-rating">
                    {'★'.repeat(Math.floor(comment.rating))}
                    {'☆'.repeat(5 - Math.floor(comment.rating))}
                  </div>
                </div>
                <div className="comment-text">{comment.text}</div>
              </div>
            ))}
            <div className="add-comment">
              <h3>Add a Comment</h3>
              <textarea placeholder="Share your thoughts or cooking tips..." rows="3"></textarea>
              <div className="comment-rating-selector">
                <span>Your Rating:</span>
                <div className="rating-stars">
                  {'☆'.repeat(5)}
                </div>
              </div>
              <button className="submit-comment-button">Submit</button>
            </div>
          </div>
        )}
      </div>
      
      <div className="recipe-author">
        <h3>By {recipe.author}</h3>
      </div>
      
      <div className="similar-recipes">
        <h2>Similar Recipes</h2>
        <div className="similar-recipes-grid">
          {getSimilarRecipes().map(similarRecipe => (
            <Link 
              to={`/recipe/${similarRecipe.id}`} 
              key={similarRecipe.id} 
              className="similar-recipe-card"
            >
              <div className="similar-recipe-image">
                <img src={similarRecipe.image} alt={similarRecipe.title} />
              </div>
              <div className="similar-recipe-info">
                <h3>{similarRecipe.title}</h3>
                <div className="similar-recipe-meta">
                  <span>
                    {'★'.repeat(Math.floor(similarRecipe.rating))}
                    {'☆'.repeat(5 - Math.floor(similarRecipe.rating))}
                  </span>
                  <span>{similarRecipe.cookingTime} mins</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default RecipeDetail;