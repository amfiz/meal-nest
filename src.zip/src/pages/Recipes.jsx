import React, { useState } from 'react';
import './Recipes.css';

const recipeData = [
  { 
    id: 1, 
    title: "Spicy Chickpea Curry", 
    rating: "4.7", 
    reviews: 80, 
    image: "spicy-chickpea-curry.jpg" 
  },
  { 
    id: 2, 
    title: "Lemon Herb Grilled Chicken", 
    rating: "4.9", 
    reviews: 112, 
    image: "lemon-herb-grilled-chicken.jpg" 
  },
  { 
    id: 3, 
    title: "Mango Smoothie Bowl", 
    rating: "4.8", 
    reviews: 99, 
    image: "mango-smoothie-bowl.jpg" 
  },
  { 
    id: 4, 
    title: "Garlic Butter Shrimp Pasta", 
    rating: "4.6", 
    reviews: 75, 
    image: "garlic-butter-shrimp-pasta.jpg" 
  },
  { 
    id: 5, 
    title: "Classic Margherita Pizza", 
    rating: "4.5", 
    reviews: 61, 
    image: "classic-margherita-pizza.jpeg" 
  },
  { 
    id: 6, 
    title: "Avocado Toast with Egg", 
    rating: "4.9", 
    reviews: 102, 
    image: "avocado-toast-with-egg.jpg" 
  },
];


const Recipes = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecipes = recipeData.filter(recipe =>
    recipe.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="recipes-container">
      <section className="search-section">
        <h1 className="recipes-title">Find Your Next Favorite Dish 🍽️</h1>
        <div className="search-bar">
          <input
            type="text"
            placeholder="Search recipes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <button className="search-button" onClick={() => setSearchTerm('')}>
            Clear
          </button>
        </div>
      </section>

      <section className="all-recipes-section">
        <h2 className="section-title">All Recipes</h2>
        <div className="recipes-grid">
  {filteredRecipes.length > 0 ? (
    filteredRecipes.map((recipe) => (
      <div className="recipe-card" key={recipe.id}>
        <div className="recipe-image">
          <img src= {recipe.image} alt={recipe.title} /></div>
                <div className="recipe-info">
                  <h3 className="recipe-title">{recipe.title}</h3>
                  <p className="recipe-meta">⭐ {recipe.rating} ({recipe.reviews} reviews)</p>
                </div>
              </div>
            ))
          ) : (
            <p style={{ textAlign: 'center', gridColumn: '1 / -1', color: 'gray' }}>No recipes found.</p>
          )}
        </div>
      </section>
    </div>
  );
};

export default Recipes;
