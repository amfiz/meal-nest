import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import RecipeCard from '../components/Recipe/RecipeCard';

const Profile = () => {
  const { userId } = useParams();
  const [user, setUser] = useState(null);
  const [userRecipes, setUserRecipes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('recipes');

  // Simulate fetching user data and recipes from an API
  useEffect(() => {
    const fetchUserData = async () => {
      setIsLoading(true);
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Sample data - replace with actual API call
        const sampleUser = {
          id: 1,
          name: 'Chef Maria',
          bio: 'Home cook and food enthusiast. Love creating simple, delicious recipes that anyone can make.',
          avatar: '/avatar1.jpg',
          joinDate: '2022-05-15',
          recipeCount: 12,
          followerCount: 128,
          followingCount: 64,
        };
        
        const sampleRecipes = [
          {
            id: 1,
            title: 'Creamy Garlic Pasta',
            image: '/pasta.jpg',
            description: 'A delicious creamy pasta with garlic and parmesan cheese that comes together in just 20 minutes.',
            rating: 4.5,
            reviews: 128,
            cookingTime: 20,
            category: 'Italian',
            tags: ['pasta', 'quick', 'vegetarian'],
          },
          {
            id: 2,
            title: 'Homemade Pizza',
            image: '/pizza.jpg',
            description: 'Easy homemade pizza with your favorite toppings.',
            rating: 4.7,
            reviews: 95,
            cookingTime: 30,
            category: 'Italian',
            tags: ['pizza', 'dinner', 'family'],
          },
          {
            id: 3,
            title: 'Chocolate Chip Cookies',
            image: '/cookies.jpg',
            description: 'Classic chocolate chip cookies that are soft in the middle and crispy on the edges.',
            rating: 4.9,
            reviews: 215,
            cookingTime: 25,
            category: 'Dessert',
            tags: ['cookies', 'dessert', 'baking'],
          },
        ];
        
        setUser(sampleUser);
        setUserRecipes(sampleRecipes);
      } catch (error) {
        console.error('Error fetching user data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserData();
  }, [userId]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-medium"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-medium text-gray-600">User not found</h2>
        <Link to="/" className="btn btn-primary mt-4">
          Back to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Profile Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center gap-8 mb-8">
          <motion.div
            initial={{ scale: 0.9 }}
            animate={{ scale: 1 }}
            className="flex-shrink-0"
          >
            <img
              src={user.avatar}
              alt={user.name}
              className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg"
            />
          </motion.div>
          
          <div className="flex-grow">
            <h1 className="text-3xl font-bold text-primary-dark mb-2">{user.name}</h1>
            <p className="text-gray-600 mb-4">{user.bio}</p>
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center text-gray-600">
                <svg
                  className="w-5 h-5 mr-1 text-primary-medium"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
                <span>Joined {new Date(user.joinDate).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center text-gray-600">
                <svg
                  className="w-5 h-5 mr-1 text-primary-medium"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v13m8-13v13m-7-13v13m-8-13v13M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"
                  />
                </svg>
                <span>{user.recipeCount} recipes</span>
              </div>
            </div>
          </div>
          
          <div className="flex-shrink-0">
            <button className="btn btn-outline px-6 py-2">
              Follow
            </button>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white p-4 rounded-lg shadow-sm text-center">
            <div className="text-2xl font-bold text-primary-dark mb-1">
              {user.recipeCount}
            </div>
            <div className="text-sm text-gray-600">Recipes</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm text-center">
            <div className="text-2xl font-bold text-primary-dark mb-1">
              {user.followerCount}
            </div>
            <div className="text-sm text-gray-600">Followers</div>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm text-center">
            <div className="text-2xl font-bold text-primary-dark mb-1">
              {user.followingCount}
            </div>
            <div className="text-sm text-gray-600">Following</div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="flex -mb-px">
            <button
              onClick={() => setActiveTab('recipes')}
              className={`mr-8 py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'recipes' ? 'border-primary-medium text-primary-dark' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
            >
              Recipes
            </button>
            <button
              onClick={() => setActiveTab('saved')}
              className={`mr-8 py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'saved' ? 'border-primary-medium text-primary-dark' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
            >
              Saved Recipes
            </button>
            <button
              onClick={() => setActiveTab('collections')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'collections' ? 'border-primary-medium text-primary-dark' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
            >
              Collections
            </button>
          </nav>
        </div>
        
        {/* Tab Content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          {activeTab === 'recipes' && (
            <div>
              {userRecipes.length === 0 ? (
                <div className="text-center py-12">
                  <svg
                    className="w-16 h-16 mx-auto text-gray-400"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1}
                      d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                    />
                  </svg>
                  <h3 className="mt-4 text-lg font-medium text-gray-600">
                    No recipes yet
                  </h3>
                  <p className="mt-2 text-gray-500">
                    {user.name} hasn't shared any recipes yet.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {userRecipes.map((recipe) => (
                    <RecipeCard key={recipe.id} recipe={recipe} />
                  ))}
                </div>
              )}
            </div>
          )}
          
          {activeTab === 'saved' && (
            <div className="text-center py-12">
              <svg
                className="w-16 h-16 mx-auto text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1}
                  d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"
                />
              </svg>
              <h3 className="mt-4 text-lg font-medium text-gray-600">
                Saved Recipes
              </h3>
              <p className="mt-2 text-gray-500">
                Recipes you save will appear here.
              </p>
            </div>
          )}
          
          {activeTab === 'collections' && (
            <div className="text-center py-12">
              <svg
                className="w-16 h-16 mx-auto text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1}
                  d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                />
              </svg>
              <h3 className="mt-4 text-lg font-medium text-gray-600">
                Recipe Collections
              </h3>
              <p className="mt-2 text-gray-500">
                Create collections to organize your favorite recipes.
              </p>
              <button className="btn btn-primary mt-4">
                Create Collection
              </button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
};

export default Profile;