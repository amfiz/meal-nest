import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const AddRecipe = () => {
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState({
    title: '',
    description: '',
    prepTime: '',
    cookTime: '',
    servings: '',
    difficulty: 'Easy',
    category: '',
    diet: '',
    ingredients: [{ name: '', amount: '', note: '' }],
    instructions: [''],
    tags: [],
    image: null,
    imagePreview: '',
  });

  const [currentTag, setCurrentTag] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = [
    'Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snack', 
    'Appetizer', 'Salad', 'Soup', 'Main Course', 'Side Dish'
  ];

  const dietOptions = [
    'None', 'Vegan', 'Vegetarian', 'Keto', 'Paleo', 
    'Gluten-Free', 'Dairy-Free', 'Nut-Free', 'Low-Carb', 'Low-Fat'
  ];

  const difficultyOptions = ['Easy', 'Medium', 'Hard'];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setRecipe({ ...recipe, [name]: value });
  };

  const handleIngredientChange = (index, field, value) => {
    const newIngredients = [...recipe.ingredients];
    newIngredients[index][field] = value;
    setRecipe({ ...recipe, ingredients: newIngredients });
  };

  const addIngredient = () => {
    setRecipe({
      ...recipe,
      ingredients: [...recipe.ingredients, { name: '', amount: '', note: '' }],
    });
  };

  const removeIngredient = (index) => {
    const newIngredients = [...recipe.ingredients];
    newIngredients.splice(index, 1);
    setRecipe({ ...recipe, ingredients: newIngredients });
  };

  const handleInstructionChange = (index, value) => {
    const newInstructions = [...recipe.instructions];
    newInstructions[index] = value;
    setRecipe({ ...recipe, instructions: newInstructions });
  };

  const addInstruction = () => {
    setRecipe({ ...recipe, instructions: [...recipe.instructions, ''] });
  };

  const removeInstruction = (index) => {
    const newInstructions = [...recipe.instructions];
    newInstructions.splice(index, 1);
    setRecipe({ ...recipe, instructions: newInstructions });
  };

  const handleTagAdd = () => {
    if (currentTag.trim() && !recipe.tags.includes(currentTag.trim())) {
      setRecipe({ ...recipe, tags: [...recipe.tags, currentTag.trim()] });
      setCurrentTag('');
    }
  };

  const removeTag = (tagToRemove) => {
    setRecipe({
      ...recipe,
      tags: recipe.tags.filter((tag) => tag !== tagToRemove),
    });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setRecipe({
        ...recipe,
        image: file,
        imagePreview: URL.createObjectURL(file),
      });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      console.log('Recipe submitted:', recipe);
      navigate('/recipes'); // Redirect to recipes page after submission
    } catch (error) {
      console.error('Error submitting recipe:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold mb-6 text-primary-dark">Share Your Recipe</h1>
        
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
          {/* Basic Information */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-primary-dark border-b pb-2">
              Basic Information
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="form-group">
                <label className="form-label">Recipe Title*</label>
                <input
                  type="text"
                  name="title"
                  value={recipe.title}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Category*</label>
                <select
                  name="category"
                  value={recipe.category}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                >
                  <option value="">Select a category</option>
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="form-group mt-4">
              <label className="form-label">Description*</label>
              <textarea
                name="description"
                value={recipe.description}
                onChange={handleInputChange}
                className="form-control"
                rows="3"
                required
              ></textarea>
              <p className="text-sm text-gray-500 mt-1">
                Tell us about your recipe. What makes it special?
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
              <div className="form-group">
                <label className="form-label">Prep Time (minutes)*</label>
                <input
                  type="number"
                  name="prepTime"
                  value={recipe.prepTime}
                  onChange={handleInputChange}
                  className="form-control"
                  min="0"
                  required
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Cook Time (minutes)*</label>
                <input
                  type="number"
                  name="cookTime"
                  value={recipe.cookTime}
                  onChange={handleInputChange}
                  className="form-control"
                  min="0"
                  required
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Servings*</label>
                <input
                  type="number"
                  name="servings"
                  value={recipe.servings}
                  onChange={handleInputChange}
                  className="form-control"
                  min="1"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <div className="form-group">
                <label className="form-label">Difficulty Level*</label>
                <select
                  name="difficulty"
                  value={recipe.difficulty}
                  onChange={handleInputChange}
                  className="form-control"
                  required
                >
                  {difficultyOptions.map((level) => (
                    <option key={level} value={level}>
                      {level}
                    </option>
                  ))}
                </select>
              </div>
              
              <div className="form-group">
                <label className="form-label">Dietary Information</label>
                <select
                  name="diet"
                  value={recipe.diet}
                  onChange={handleInputChange}
                  className="form-control"
                >
                  <option value="">None</option>
                  {dietOptions.map((diet) => (
                    <option key={diet} value={diet}>
                      {diet}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {/* Recipe Image */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-primary-dark border-b pb-2">
              Recipe Image
            </h2>
            
            <div className="flex flex-col md:flex-row items-start gap-6">
              <div className="w-full md:w-1/3">
                <div className="border-2 border-dashed border-gray-300 rounded-lg h-48 flex items-center justify-center overflow-hidden">
                  {recipe.imagePreview ? (
                    <img
                      src={recipe.imagePreview}
                      alt="Recipe preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-4">
                      <svg
                        className="w-12 h-12 mx-auto text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                        />
                      </svg>
                      <p className="mt-2 text-sm text-gray-600">
                        Upload a photo of your recipe
                      </p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="w-full md:w-2/3">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Upload Image*
                </label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary-extra-light file:text-primary-medium hover:file:bg-primary-light hover:file:text-white"
                  required
                />
                <p className="mt-2 text-sm text-gray-500">
                  Upload a high-quality image of your finished dish (JPEG or PNG, max 5MB)
                </p>
              </div>
            </div>
          </div>
          
          {/* Ingredients */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-primary-dark border-b pb-2">
              Ingredients
            </h2>
            
            {recipe.ingredients.map((ingredient, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="grid grid-cols-12 gap-3 mb-3 items-end"
              >
                <div className="col-span-5">
                  <label className="form-label">Ingredient*</label>
                  <input
                    type="text"
                    value={ingredient.name}
                    onChange={(e) => handleIngredientChange(index, 'name', e.target.value)}
                    className="form-control"
                    required
                  />
                </div>
                
                <div className="col-span-3">
                  <label className="form-label">Amount*</label>
                  <input
                    type="text"
                    value={ingredient.amount}
                    onChange={(e) => handleIngredientChange(index, 'amount', e.target.value)}
                    className="form-control"
                    required
                  />
                </div>
                
                <div className="col-span-3">
                  <label className="form-label">Note</label>
                  <input
                    type="text"
                    value={ingredient.note}
                    onChange={(e) => handleIngredientChange(index, 'note', e.target.value)}
                    className="form-control"
                  />
                </div>
                
                <div className="col-span-1">
                  {recipe.ingredients.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeIngredient(index)}
                      className="btn btn-outline p-2 text-red-500 hover:bg-red-50"
                    >
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                        />
                      </svg>
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
            
            <button
              type="button"
              onClick={addIngredient}
              className="btn btn-outline mt-2 flex items-center"
            >
              <svg
                className="w-5 h-5 mr-1"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                />
              </svg>
              Add Another Ingredient
            </button>
          </div>
          
          {/* Instructions */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-primary-dark border-b pb-2">
              Instructions
            </h2>
            
            {recipe.instructions.map((instruction, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2 }}
                className="mb-4"
              >
                <div className="flex items-start">
                  <span className="bg-primary-medium text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 mt-1 flex-shrink-0">
                    {index + 1}
                  </span>
                  <div className="flex-grow">
                    <label className="form-label">Step {index + 1}*</label>
                    <textarea
                      value={instruction}
                      onChange={(e) => handleInstructionChange(index, e.target.value)}
                      className="form-control"
                      rows="3"
                      required
                    ></textarea>
                  </div>
                  {recipe.instructions.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeInstruction(index)}
                      className="btn btn-outline p-2 ml-3 text-red-500 hover:bg-red-50"
                    >
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                        />
                      </svg>
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
            
            <button
              type="button"
              onClick={addInstruction}
              className="btn btn-outline mt-2 flex items-center"
            >
              <svg
                className="w-5 h-5 mr-1"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                />
              </svg>
              Add Another Step
            </button>
          </div>
          
          {/* Tags */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-primary-dark border-b pb-2">
              Tags
            </h2>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {recipe.tags.map((tag) => (
                <motion.span
                  key={tag}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="inline-flex items-center px-3 py-1 rounded-full bg-primary-extra-light text-primary-medium text-sm"
                >
                  {tag}
                  <button
                    type="button"
                    onClick={() => removeTag(tag)}
                    className="ml-2 text-primary-medium hover:text-primary-dark"
                  >
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </motion.span>
              ))}
            </div>
            
            <div className="flex">
              <input
                type="text"
                value={currentTag}
                onChange={(e) => setCurrentTag(e.target.value)}
                placeholder="Add tags (e.g., quick, spicy, gluten-free)"
                className="form-control flex-grow mr-2"
              />
              <button
                type="button"
                onClick={handleTagAdd}
                className="btn btn-outline whitespace-nowrap"
              >
                Add Tag
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Add relevant tags to help others find your recipe (max 5 tags)
            </p>
          </div>
          
          {/* Submit */}
          <div className="flex justify-end">
            <button
              type="submit"
              className="btn btn-primary px-6 py-3"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <svg
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Submitting...
                </>
              ) : (
                'Publish Recipe'
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default AddRecipe;