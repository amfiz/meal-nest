import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import Navbar from './components/Navigation/Navbar';
import Footer from './components/Navigation/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Recipes from './pages/Recipes';
import RecipeDetail from './pages/RecipeDetail';
import AddRecipe from './pages/AddRecipe';
import Profile from './pages/Profile';
import TopRecipes from './pages/TopRecipes';
import ShoppingList from './pages/ShoppingList';
import AnimatedRoute from './components/UI/AnimatedRoute';
import './assets/styles/global.css';

// App theme configuration
const themeColors = {
  darkGreen: '#1E3A29',
  mediumGreen: '#2A5738',
  lightGreen: '#4A7856',
  cream: '#F9F3E9',
  accent: '#E3B448',
  white: '#FFFFFF',
  lightGray: '#F5F5F5'
};

// Apply theme colors to CSS variables
const ThemeProvider = ({ children }) => {
  useEffect(() => {
    // Set CSS variables for the theme
    document.documentElement.style.setProperty('--color-primary-dark', themeColors.darkGreen);
    document.documentElement.style.setProperty('--color-primary-medium', themeColors.mediumGreen);
    document.documentElement.style.setProperty('--color-primary-light', themeColors.lightGreen);
    document.documentElement.style.setProperty('--color-cream', themeColors.cream);
    document.documentElement.style.setProperty('--color-accent', themeColors.accent);
    
    // Set body background
    document.body.style.backgroundColor = themeColors.cream;
    document.body.style.color = themeColors.darkGreen;
  }, []);

  return children;
};

// ScrollToTop component to reset scroll position on navigation
const ScrollToTop = () => {
  const { pathname } = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  
  return null;
};

function App() {
  return (
    <Router>
      <ThemeProvider>
        <ScrollToTop />
        <div className="min-h-screen flex flex-col" style={{ backgroundColor: themeColors.cream }}>
          <Navbar />
          <main className="flex-grow pt-16 sm:pt-20">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<AnimatedRoute><Home /></AnimatedRoute>} />
                <Route path="/login" element={<AnimatedRoute><Login /></AnimatedRoute>} />
                <Route path="/register" element={<AnimatedRoute><Register /></AnimatedRoute>} />
                <Route path="/recipes" element={<AnimatedRoute><Recipes /></AnimatedRoute>} />
                <Route path="/recipes/:id" element={<AnimatedRoute><RecipeDetail /></AnimatedRoute>} />
                <Route path="/add-recipe" element={<AnimatedRoute><AddRecipe /></AnimatedRoute>} />
                <Route path="/profile" element={<AnimatedRoute><Profile /></AnimatedRoute>} />
                <Route path="/top-recipes" element={<AnimatedRoute><TopRecipes /></AnimatedRoute>} />
                <Route path="/shopping-list" element={<AnimatedRoute><ShoppingList /></AnimatedRoute>} />
              </Routes>
            </AnimatePresence>
          </main>
          <Footer />
        </div>
      </ThemeProvider>
    </Router>
  );
}

export default App;